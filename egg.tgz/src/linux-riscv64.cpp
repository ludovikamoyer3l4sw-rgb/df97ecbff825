// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("linux riscv64\n", stdout);
  return lionss_run_workload("linux-riscv64");
}
