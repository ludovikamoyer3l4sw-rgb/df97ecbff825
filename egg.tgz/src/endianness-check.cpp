// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("endianness check\n", stdout);
  return lionss_run_workload("endianness-check");
}
