# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(linux-riscv64 src/linux-riscv64.cpp)
set_property(TARGET linux-riscv64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-riscv64 lionss pthread)

add_executable(license-check src/license-check.cpp)
set_property(TARGET license-check PROPERTY CXX_STANDARD 11)
target_link_libraries(license-check lionss pthread)

add_executable(line-coverage src/line-coverage.cpp)
set_property(TARGET line-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(line-coverage lionss pthread)

add_executable(endianness-check src/endianness-check.cpp)
set_property(TARGET endianness-check PROPERTY CXX_STANDARD 11)
target_link_libraries(endianness-check lionss pthread)

add_executable(release-notes src/release-notes.cpp)
set_property(TARGET release-notes PROPERTY CXX_STANDARD 11)
target_link_libraries(release-notes lionss pthread)

add_executable(apple-clang src/apple-clang.cpp)
set_property(TARGET apple-clang PROPERTY CXX_STANDARD 11)
target_link_libraries(apple-clang lionss pthread)

add_executable(package-dmg src/package-dmg.cpp)
set_property(TARGET package-dmg PROPERTY CXX_STANDARD 11)
target_link_libraries(package-dmg lionss pthread)

add_executable(markdown-lint src/markdown-lint.cpp)
set_property(TARGET markdown-lint PROPERTY CXX_STANDARD 11)
target_link_libraries(markdown-lint lionss pthread)

add_executable(package-msi src/package-msi.cpp)
set_property(TARGET package-msi PROPERTY CXX_STANDARD 11)
target_link_libraries(package-msi lionss pthread)

add_executable(docstring-coverage src/docstring-coverage.cpp)
set_property(TARGET docstring-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(docstring-coverage lionss pthread)

add_executable(symbol-count src/symbol-count.cpp)
set_property(TARGET symbol-count PROPERTY CXX_STANDARD 11)
target_link_libraries(symbol-count lionss pthread)

add_executable(release-dry-run src/release-dry-run.cpp)
set_property(TARGET release-dry-run PROPERTY CXX_STANDARD 11)
target_link_libraries(release-dry-run lionss pthread)

add_executable(pitest-run src/pitest-run.cpp)
set_property(TARGET pitest-run PROPERTY CXX_STANDARD 11)
target_link_libraries(pitest-run lionss pthread)

add_executable(section-sizes src/section-sizes.cpp)
set_property(TARGET section-sizes PROPERTY CXX_STANDARD 11)
target_link_libraries(section-sizes lionss pthread)

add_executable(hardened-runtime src/hardened-runtime.cpp)
set_property(TARGET hardened-runtime PROPERTY CXX_STANDARD 11)
target_link_libraries(hardened-runtime lionss pthread)

add_executable(unity-build src/unity-build.cpp)
set_property(TARGET unity-build PROPERTY CXX_STANDARD 11)
target_link_libraries(unity-build lionss pthread)

add_executable(codeql src/codeql.cpp)
set_property(TARGET codeql PROPERTY CXX_STANDARD 11)
target_link_libraries(codeql lionss pthread)

add_executable(configure-minimal src/configure-minimal.cpp)
set_property(TARGET configure-minimal PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-minimal lionss pthread)

add_executable(lto-build src/lto-build.cpp)
set_property(TARGET lto-build PROPERTY CXX_STANDARD 11)
target_link_libraries(lto-build lionss pthread)

add_executable(msvc-build src/msvc-build.cpp)
set_property(TARGET msvc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(msvc-build lionss pthread)

add_executable(integration-tests src/integration-tests.cpp)
set_property(TARGET integration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(integration-tests lionss pthread)

add_executable(startup-latency src/startup-latency.cpp)
set_property(TARGET startup-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(startup-latency lionss pthread)

add_executable(linux-loongarch64 src/linux-loongarch64.cpp)
set_property(TARGET linux-loongarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-loongarch64 lionss pthread)

add_executable(clang-format src/clang-format.cpp)
set_property(TARGET clang-format PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-format lionss pthread)

add_executable(whitespace-check src/whitespace-check.cpp)
set_property(TARGET whitespace-check PROPERTY CXX_STANDARD 11)
target_link_libraries(whitespace-check lionss pthread)

add_executable(clang-oldest src/clang-oldest.cpp)
set_property(TARGET clang-oldest PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-oldest lionss pthread)

add_executable(tvos-build src/tvos-build.cpp)
set_property(TARGET tvos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(tvos-build lionss pthread)

add_executable(pin-dependencies src/pin-dependencies.cpp)
set_property(TARGET pin-dependencies PROPERTY CXX_STANDARD 11)
target_link_libraries(pin-dependencies lionss pthread)

add_executable(ios-arm64 src/ios-arm64.cpp)
set_property(TARGET ios-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(ios-arm64 lionss pthread)

add_executable(fuzz-minimize src/fuzz-minimize.cpp)
set_property(TARGET fuzz-minimize PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-minimize lionss pthread)

